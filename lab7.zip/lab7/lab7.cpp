// ЛР7, вариант 7 — цикл while, n = 62343351
// количество цифр, сумма цифр, первая цифра, количество чётных цифр
// на C++ и ассемблерной вставкой, сравниваем
//   g++ -masm=intel lab7.cpp -o lab7 && ./lab7
#include <iostream>
#include <cstdlib>
using namespace std;

int main()
{
    int number = 62343351;

    // C++, программа из методички, дополненная тремя задачами
    int n = number, k = 0, sum = 0, first = 0, even = 0;
    div_t q;
    while (n != 0) {
        q = div(n, 10);
        n = q.quot;             // отбросили последнюю цифру
        k++;
        sum += q.rem;           // q.rem - отброшенная цифра
        first = q.rem;          // цифры идут с конца, последней останется первая
        if (q.rem % 2 == 0)
            even++;
    }

    // ассемблер
    int a_k, a_sum, a_first, a_even;
    asm(
        "mov eax, %[n]\n\t"
        "mov ecx, 10\n\t"
        "xor %[k], %[k]\n\t"
        "xor %[sum], %[sum]\n\t"
        "xor %[first], %[first]\n\t"
        "xor %[even], %[even]\n"
        "while%=:\n\t"
        "cmp eax, 0\n\t"
        "je end%=\n\t"              // n == 0 - выход, проверка до тела
        "xor edx, edx\n\t"          // div делит edx:eax
        "div ecx\n\t"               // eax = n / 10, edx = цифра
        "inc %[k]\n\t"
        "add %[sum], edx\n\t"
        "mov %[first], edx\n\t"
        "test edx, 1\n\t"
        "jnz odd%=\n\t"             // младший бит 1 -> нечётная
        "inc %[even]\n"
        "odd%=:\n\t"
        "jmp while%=\n"
        "end%=:"
        : [k] "=&r" (a_k), [sum] "=&r" (a_sum),
          [first] "=&r" (a_first), [even] "=&r" (a_even)
        : [n] "r" (number)
        : "eax", "ecx", "edx", "cc");

    cout << "n = " << number << endl;
    cout << "количество цифр: C++ = " << k << ", ассемблер = " << a_k << endl;
    cout << "сумма цифр:      C++ = " << sum << ", ассемблер = " << a_sum << endl;
    cout << "первая цифра:    C++ = " << first << ", ассемблер = " << a_first << endl;
    cout << "чётных цифр:     C++ = " << even << ", ассемблер = " << a_even << endl;
    cout << (k == a_k && sum == a_sum && first == a_first && even == a_even
                 ? "результаты совпадают" : "результаты НЕ совпадают") << endl;
    return 0;
}
