; ЛР7, вариант 7 — цикл while (с предусловием) через cmp и переходы
; n = 62343351: количество цифр, сумма цифр, первая цифра, количество чётных цифр
; должно выйти 8, 27, 6 и 3 (посчитано в решение.txt)
%include "io64.inc"

section .data
    n         dd 62343351
    k         dd 0
    sum       dd 0
    first     dd 0
    even_cnt  dd 0

section .text
global main
main:
    mov rbp, rsp; for correct debugging

    mov eax, [n]            ; eax - то, что осталось от числа
    mov ecx, 10             ; делитель
.while:
    cmp eax, 0
    je .end_while           ; n == 0 - выход, проверка до тела, как у while
    xor edx, edx            ; div делит edx:eax, старшая часть должна быть 0
    div ecx                 ; eax = n / 10 (цифру отбросили), edx = эта цифра
    inc dword [k]           ; k++
    add [sum], edx          ; сумма цифр
    mov [first], edx        ; цифры идут с конца, последней запишется первая
    test edx, 1
    jnz .odd                ; младший бит 1 -> нечётная
    inc dword [even_cnt]
.odd:
    jmp .while
.end_while:

    PRINT_STRING "n = "
    PRINT_DEC 4, [n]
    NEWLINE
    PRINT_STRING "количество цифр = "
    PRINT_DEC 4, [k]
    NEWLINE
    PRINT_STRING "сумма цифр = "
    PRINT_DEC 4, [sum]
    NEWLINE
    PRINT_STRING "первая цифра = "
    PRINT_DEC 4, [first]
    NEWLINE
    PRINT_STRING "чётных цифр = "
    PRINT_DEC 4, [even_cnt]
    NEWLINE

    xor rax, rax
    ret

section .note.GNU-stack noalloc noexec nowrite progbits
